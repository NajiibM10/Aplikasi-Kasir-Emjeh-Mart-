<?php 

	class transaksi_model extends CI_model{
		public function getDataTransaksi()
		{
			return $this->db->get("det_transaksi")->result_array();
		}

        public function getDataTransaksiByNota($no_nota)
        {
            $this->db->where( "no_nota" , $no_nota);
            $data = $this->db->get("det_transaksi")->result_array();
            return $data;
        }

		public function getData()
        {
            $this->db->select('*');
            $this->db->from("det_transaksi");
            $this->db->join('head_transaksi', 'head_transaksi.no_nota = det_transaksi.no_nota');
            $this->db->order_by("id_barang", "ASC");
            $query = $this->db->get();
            return $query->result_array();
        }

        public function getTransaksiByid($no_nota)
        {
            $this->db->select('*');
            $this->db->from('det_transaksi');
            $this->db->where('no_nota' ,$no_nota);
            $query = $this->db->get();
            return $query->row_array();
        }

        public function cariDataTransaksi()
        {
        $keyword = $this->input->post('keyword', true);
        $this->db->like('no_nota', $keyword); 
        return $this->db->get('det_transaksi')->result_array();
        }

        public function getDataTransaksifill($date)
        {
            $this->db->where("tgl_transaksi", $date);
            $data = $this->db->get("det_transaksi")->result_array();
            return $data;
        }

	}

 ?>