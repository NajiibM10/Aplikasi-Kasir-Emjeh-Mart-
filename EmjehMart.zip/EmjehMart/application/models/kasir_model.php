<?php

    class kasir_model extends CI_model{
        public function getDataBarang()
        {
            return $this->db->get("barang")->result_array();
        }

        public function getData()
        {
            $this->db->select('*');
            $this->db->from('barang');
            $this->db->join('barang', 'barang.id_barang = barang.id_barang');
            $this->db->order_by("nama_barang", "ASC");
            $query = $this->db->get();
            return $query->result_array();
        }
        
        public function tambahDataBarang()
        {
            $data = [
                'id_barang' => $this->input->post("id_barang", true),
                'nama_barang' => $this->input->post("nama_barang", true),
                'harga_barang' => $this->input->post("harga_barang", true),
                'stok_barang' => $this->input->post("stok_barang", true),
            ];

            $this->db->insert('barang', $data);
        }

        public function hapusDataBarang($id)
        {
            $this->db->where("id_barang", $id);
            $this->db->delete("barang");
        }

        public function getBarangByid($id)
        {
            $this->db->select('*');
            $this->db->from('barang');
            $this->db->where('id_barang' ,$id);
            $query = $this->db->get();
            return $query->row_array();
        }

        public function ubahDataBarang($id_barang)
        {
            $data = [
                'nama_barang' => $this->input->post("nama_barang", true),
                'harga_barang' => $this->input->post("harga_barang", true),
                'stok_barang' => $this->input->post("stok_terbaru", true)
            ];
            $this->db->where('id_barang',$id_barang);
            $this->db->update('barang', $data);
        }


        public function hapusDataTransaksi($no_nota)
        {
            $this->db->where("no_nota", $no_nota);
            $this->db->delete("head_transaksi");
        }

        public function save_as($data1,$data2)
        {
            $insert1 = $this->db->insert('head_transaksi',$data1);
            $no_nota = $this->db->insert_id();


            if (!$no_nota==0) {    
                $data2 = array();
                foreach ($this->cart->contents() as $items) {
                $data2[]= array(
                    'tgl_transaksi'=>date('Y-m-d'),
                    'no_nota'=>$no_nota,
                    'id_barang'=>$items['id'],
                    'nama_barang'=>$items['name'],
                    'harga_barang'=>$items['price'],
                    'quantity'=>$items['qty'],
                    'subtotal'=>$items['subtotal']
                );
                $insert2 = $this->db->insert_batch('det_transaksi',$data2);
                }
            }
        }

        public function cariDataBarang()
        {
        $keyword = $this->input->post('keyword', true);
        $this->db->like('id_barang', $keyword);
        return $this->db->get('barang')->result_array();
        }


        public function login()
        {
            $username = $this->input->post("username");
            $password = $this->input->post("password");
            $this->db->where('username', $username);
            $data = $this->db->get('pegawai');
            if($data->num_rows() > 0){
                $dataUser = $data->row_array();
                if (password_verify($password, $dataUser["password"]) == true) {
                    return $dataUser;
                }else{
                    return false;
                }
            }else{
                return false;
            }
        }     
    }
