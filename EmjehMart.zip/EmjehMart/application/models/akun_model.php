<?php 

    class akun_model extends CI_model{
        public function getDataAkun()
        {
            return $this->db->get("pegawai")->result_array();
        }

        public function getData()
        {
            $this->db->select('*');
            $this->db->from('pegawai');
            $this->db->join('pegawai', 'pegawai.kode_pegawai = jabatan.kode_jabatan');
            $this->db->order_by("nama_pegawai", "ASC");
            $query = $this->db->get();
            return $query->result_array();
        }

        public function tambahDataAkun()
        {
            $data = [
                'kode_pegawai' => $this->input->post("kode_pegawai", true),
                'username' => $this->input->post("username", true),
                'password' => $this->input->post("password", true),
                'nama_pegawai' => $this->input->post("nama_pegawai", true),
                'hak_akses' => $this->input->post("hak_akses", true),
            ];
            $this->db->insert('pegawai', $data);
        }

        public function hapusDataAkun($id)
        {
            $this->db->where("kode_pegawai", $id);
            $this->db->delete("pegawai");
        }

        public function getAkunByKode($kode)
        {
            $this->db->select('*');
            $this->db->from('pegawai');
            $this->db->where('kode_pegawai' ,$kode);
            $this->db->join('jabatan', 'jabatan.kode_jabatan = pegawai.kode_pegawai');
            $query = $this->db->get();
            return $query->row_array();
        }

        public function ubahDataAkun()
        {
            $data = [
                'kode_pegawai' => $this->input->post("kode_pegawai", true),
                'username' => $this->input->post("username", true),
                'password' => $this->input->post("password", true),
                'nama_pegawai' => $this->input->post("nama_pegawai", true),
                'hak_akses' => $this->input->post("hak_akses", true),
            ];
            $this->db->where('kode_pegawai', $this->input->post("kode"));
            $this->db->update('pegawai', $data);
        }

        public function ambillogin($username,$password)
        {
            $this->db->where('username', $username);
            $this->db->where('password', $password);
        }
    }

 ?>