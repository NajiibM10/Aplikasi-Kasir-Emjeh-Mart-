<script>
    function hapus(id_barang) {
        Swal({
            title: 'Yakin Mau Hapus?',
            text: "Tekan 'Hapus' Untuk Meneruskan Penghapusan",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            cancelButtonText: 'Batal',
            confirmButtonText: 'Hapus'
        }).then((result) => {
            if (result.value) {
                Swal({
                    title: 'Sukses!',
                    text: 'Penghapusan Data Berhasil.',
                    type: 'success'
                }).then((result) => {
                    if(result.value) {
                        document.location.href = '<?= base_url()?>kasir/hapusDataBarang/' + id_barang;
                    }
                })
            }
        })
    }

    function hapusA(kode_pegawai) {
        Swal({
            title: 'Yakin Mau Hapus?',
            text: "Tekan 'Hapus' Untuk Meneruskan Penghapusan",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            cancelButtonText: 'Batal',
            confirmButtonText: 'Hapus'
        }).then((result) => {
            if (result.value) {
                Swal({
                    title: 'Sukses!',
                    text: 'Penghapusan Data Berhasil.',
                    type: 'success'
                }).then((result) => {
                    if(result.value) {
                        document.location.href = '<?= base_url()?>kasir/hapusDataAkun/' + kode_pegawai;
                    }
                })
            }
        })
    }

    function hapusT(no_nota) {
        Swal({
            title: 'Yakin Mau Hapus?',
            text: "Tekan 'Hapus' Untuk Meneruskan Penghapusan",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            cancelButtonText: 'Batal',
            confirmButtonText: 'Hapus'
        }).then((result) => {
            if (result.value) {
                Swal({
                    title: 'Sukses!',
                    text: 'Penghapusan Data Berhasil.',
                    type: 'success'
                }).then((result) => {
                    if(result.value) {
                        document.location.href = '<?= base_url()?>kasir/hapusDataTransaksi/' + no_nota;
                    }
                })
            }
        })
    }
    $(document).ready(function() {
        $("#btnLogout").on('click', function() {
            Swal({
            title: 'Logout?',
            text: "Tekan 'Logout' Untuk Keluar",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            cancelButtonText: 'Batal',
            confirmButtonText: 'Logout'
        }).then((result) => {
            if (result.value) {
                Swal({
                    title: 'Sukses!',
                    text: 'Logout Berhasil.',
                    type: 'success'
                }).then((result) => {
                    if(result.value) {
                        document.location.href = '<?= base_url()?>login/logout';
                    }
                })
            }
        })
        });
    });
</script>