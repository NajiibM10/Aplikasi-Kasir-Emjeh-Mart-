<!DOCTYPE html>
<html lang="en">
<head>
    <title>EmjehMart</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?= base_url('assets/bootstrap/css/bootstrap.min.css') ?>">
    <link rel="stylesheet" href="<?= base_url('assets/font-awesome/css/font-awesome.min.css') ?>">
    <link rel="stylesheet" href="<?= base_url('assets/datatables/css/dataTables.bootstrap.css') ?>">
    <link rel="stylesheet" href="<?= base_url(); ?>assets/sweetalert2-7.32.4/package/dist/sweetalert2.min.css">
    
    <script src="<?= base_url(); ?>assets/sweetalert2-7.32.4/package/dist/sweetalert2.all.min.js"></script>
    <script src="<?= base_url('assets/jquery-2.1.4.min.js') ?>"></script>
    <script src="<?= base_url('assets/bootstrap-3.3.5/js/bootstrap.min.js') ?>"></script>
    <script src="<?= base_url('assets/datatables/js/jquery.dataTables.min.js') ?>"></script>
    <script src="<?= base_url('assets/datatables/js/dataTables.bootstrap.js') ?>"></script>
    <script src="<?= base_url('assets/maskMoney/jquery.maskMoney.min.js') ?>"></script>
    <style type="text/css">
        #header,#footer{
            color: #fff;
            text-align: center;
        }

        #header h1{
            margin: 0;
            padding: 10px;
        }
        .row{
    		width: 100%;
    		margin-left: 0;
		}
    </style>
</head>
<body style="background-image: url(assets/img/2.jpg);
            background-size: cover;
">
    <br>
  <div id="header">
	<h1>Emjeh-Mart</h1>
  </div>
    <div class="row">
        <div class="col-md-4"></div>
        <div class="col-md-4">
            <div class="card" style="margin-top:100px; background-color: grey;
            ">
                <div class="card-header font-weight-bold">
                    <center><h5>LOGIN</h5></center> 
                </div>
<br>
                <?= $this->session->flashdata('messege');?>

                <div class="card-body">
                    <form class="form" action="<?php echo site_url('login/auth') ?>" method="post">
                        
                        <input type="text" name="username" id="username" class="form-control" autocomplete="off" placeholder="Username"><br>
                        <input type="password" name="password" id="password" class="form-control autocomplete="off"" placeholder="Password"><br>
                        <button type="submit" style="margin-top:20px;" class="btn btn-dark w-100">Login</button>
                    </form>
                </div>
              <div class="col-md-12" id="footer">
                <small>Copyright <?= date('Y') ?>, Najiib Muhammad J.</small>
              </div>
            </div>
        </div>
        <div class="col-md-4"></div>
    </div>

</body>