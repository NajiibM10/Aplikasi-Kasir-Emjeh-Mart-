<?php  
	require 'assets/fpdf/fpdf.php';

	$pdf = new FPDF('P','mm','a4');
	$pdf -> AddPage();
	$pdf -> SetFont('Arial','B','16');

	$pdf -> Cell(190,6,'EMJEHMART ',0,1,'C');
	$pdf -> SetFont('Arial','B',10);
	$pdf -> Cell(190,5,'Jl. Paguyuban No 12B kel.Cimahi Tengah Kec.Padasuka',0,1,'C');
	$pdf -> Cell(190,6,'Telp : 022-82172111 Email : Jidanm10@gmail.com Kota Cimahi 40512',0,1,'C');
	

	

	$pdf -> Cell(190,3,'','B',1,'L');
	$pdf -> Cell(190,1,'','B',1,'L');
	$pdf -> Ln(10);



	$pdf -> SetFont('Arial','B',15);
	$pdf -> Cell(190,11,'LAPORAN TRANSAKSI',0,1,'C');

	$pdf -> SetFont('Arial','B',10);
	$pdf -> Cell(40,6,'ID BARANG',1,0,'C');
	$pdf -> Cell(45,6,'NAMA BARANG',1,0,'C');
	$pdf -> Cell(30,6,'STOK',1,0,'C');
	$pdf -> Cell(40,6,'HARGA',1,1,'C');


    foreach ($barang as $barang) {
        $pdf -> SetFont('Arial','B',10);
        $pdf -> Cell(40,6,$barang["id_barang"],1,0,'C');
        $pdf -> Cell(45,6,$barang["nama_barang"],1,0,'C');
        $pdf -> Cell(30,6,$barang["stok_barang"],1,0,'C');
        $pdf -> Cell(40,6,$barang["harga_barang"],1,1,'C');

        
    }

    
	$pdf -> Output('I', "report_barang.php",false);


?>