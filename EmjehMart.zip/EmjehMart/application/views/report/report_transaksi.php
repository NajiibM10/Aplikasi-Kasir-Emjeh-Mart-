<?php

require 'assets/fpdf/fpdf.php';

$pdf = new FPDF('P','mm',array(75,58));
$pdf->AddPage();

$pdf -> SetFont('Arial','','6');
$pdf -> Cell(35,4,'EMJEHMART ',0,1,'C');

$pdf -> SetFont('Arial','','3');
$pdf -> Cell(35,0,'Jl. Paguyuban No 12B kel.Cimahi Tengah Kec.Padasuka',0,1,'C');
$pdf -> Cell(35,4,'Telp : 022-82172111 Email : Jidanm10@gmail.com Kota Cimahi 40512',0,1,'C');
$pdf -> Cell(40,0,'','B',1,'L');

$pdf -> Cell(35,5,'STRUK BELANJA',0,1,'C');
$pdf->Cell(3, 1, 'Date', 0, 0);
$pdf->Cell(0, 1, date(' : Y-m-d'), 0, 1);
$pdf->Cell(7, 1, 'Username :', 0, 0);
$pdf->Cell(0, 1, $_SESSION['username'], 0, 1);
$pdf -> Ln(1);

	$pdf -> Cell(8,6,'Nota',1,0,'C');
	$pdf -> Cell(10,6,'ID',1,0,'C');
	$pdf -> Cell(8,6,'Nama',1,0,'C');
	$pdf -> Cell(7,6,'QTY',1,0,'C');
	$pdf -> Cell(10,6,'TOTAL',1,1,'C');
		
	foreach ($transaksi as $row) {
		$pdf -> Cell(8,6,$row["no_nota"],1,0,'C');
		$pdf -> Cell(10,6,$row["id_barang"],1,0,'C');
		$pdf -> Cell(8,6,$row["nama_barang"],1,0,'C');
		$pdf -> Cell(7,6,$row["quantity"],1,0,'C');
		$pdf -> Cell(10,6,$row["subTotal"],1,1,'C');
	}



$pdf->Ln(8);
$pdf->Cell(6, 2, 'Total    :', 0, 0);
$pdf->Cell(10, 2, '4.000',0,1);

$pdf->Cell(6, 2, 'Bayar  :', 0, 0);
$pdf->Cell(10, 2,  '5.000', 0, 1);

$pdf->Cell(8, 2, 'Kembali  :', 0, 0);
$pdf->Cell(10, 2, '1.000', 0, 1);




$pdf->Output('I', "report_transaksi.php",false);

?>
