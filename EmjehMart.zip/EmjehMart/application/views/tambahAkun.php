<!DOCTYPE html>
<html lang="en">
<head>
    <title>EmjehMart</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?= base_url('assets/bootstrap/css/bootstrap.min.css') ?>">
    <link rel="stylesheet" href="<?= base_url('assets/font-awesome/css/font-awesome.min.css') ?>">
    <link rel="stylesheet" href="<?= base_url('assets/datatables/css/dataTables.bootstrap.css') ?>">

    <script src="<?= base_url('assets/jquery-2.1.4.min.js') ?>"></script>
    <script src="<?= base_url('assets/bootstrap-3.3.5/js/bootstrap.min.js') ?>"></script>
    <script src="<?= base_url('assets/datatables/js/jquery.dataTables.min.js') ?>"></script>
    <script src="<?= base_url('assets/datatables/js/dataTables.bootstrap.js') ?>"></script>
    <script src="<?= base_url('assets/maskMoney/jquery.maskMoney.min.js') ?>"></script>
    <style type="text/css">
        #header,#footer{
            background-color: #696969;
            color: #fff;
            text-align: center;
        }
        #header{
            margin-bottom: 30px;
        }
        #header h1{
            margin: 0;
            padding: 15px;
        }
        #footer{
            padding: 3px;
        }
        
    </style>
</head>
<body>
<div id="header">
<h1>Emjeh-Mart</h1>
</div><!-- end header -->
 <div class="row" style="margin-top:20px;margin-bottom:20px;">
   <div class="col-md-3"></div>
    <div class="col-md-6">
        <div class="card float-center bg-light">
            <div class="card-header">
                <h3>Tambah Data Akun</h3>
            </div>
            <div class="card-body">
                <form action="" method="post">
                    <div class="form-group">
                        <label for="kode_pegawai">KODE PEGAWAI :</label>
                        <input class="form-control" id="kode_pegawai" type="text" name="kode_pegawai" autocomplete="off">
                        <small class="form-text text-danger"><?= form_error('kode_pegawai');?></small>
                    </div>
                    <div class="form-group">
                        <label for="nama_pegawai">NAMA PEGAWAI :</label>
                        <input class="form-control" id="nama_pegawai" type="text" name="nama_pegawai" autocomplete="off">
                        <small class="form-text text-danger"><?= form_error('nama_pegawai');?></small>
                        </div>
                    <div class="form-group">
                        <label for="username">USERNAME :</label>
                        <input class="form-control" id="username" type="text" name="username" autocomplete="off">
                        <small class="form-text text-danger"><?= form_error('username');?></small>
                        </div>
                    <div class="form-group">
                        <label for="password">PASSWORD :</label>
                        <input class="form-control" id="password" type="text" name="password" autocomplete="off">
                        <small class="form-text text-danger"><?= form_error('password');?></small>
                        </div>    
                    <div class="form-group">
                        <label class="col-form-label" for="hak_akses">HAK AKSES</label>
                        <select name="hak_akses" class="form-control" id="hak_akses" required="">
                            <option value=""> ... </option>
                            <option value="Admin">Admin</option>
                            <option value="Kasir">Kasir</option>
                        </select>
                    </div>
                        <button type="submit" name="submit" class="btn btn-primary form-control" style="margin-top:5px;">Tambah</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="col-md-3"></div>
</div>
