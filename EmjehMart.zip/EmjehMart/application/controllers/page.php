<?php 

	class page extends CI_Controller{
		function __construct(){
			parent::__construct();
			if ($this->session->userdata('logged_in') !== TRUE) {
				redirect('login');
			}
		}

		function pegawai(){
			//Allowing akses to author only
			if ($this->session->userdata('hak_akses')=='admin') {
				redirect('kasir/index');
			}else if ($this->session->userdata('hak_akses')=='kasir') {
				redirect('kasir/kasir');
			}else{
				echo "acces denied";
			}
		}
	}

 ?>