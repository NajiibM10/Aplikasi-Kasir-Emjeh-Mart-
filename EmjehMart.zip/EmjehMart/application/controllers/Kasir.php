<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kasir extends CI_Controller {
	public function __construct()
	{
        parent::__construct();
        $this->load->model("kasir_model");
        $this->load->model("akun_model");
        $this->load->model("transaksi_model"); 
        $this->load->library("form_validation");
    }

	public function index()
	{
		$this->load->model('M_barang');

		$data['barang'] = $this->M_barang->get();

		$this->load->view('kasir',$data);
		$this->load->view("footer");
	}

	public function kasir()
	{
		$this->load->model('M_barang');

		$data['barang'] = $this->M_barang->get();

		$this->load->view('kasir/kasir',$data);
		$this->load->view("footer");
	}

	public function getbarang($id)
	{

		$this->load->model('M_barang');

		$barang = $this->M_barang->get_by_id($id);

		if ($barang) {

			if ($barang->stok_barang == '0') {
				$disabled = 'disabled';
				$info_stok = '<span class="help-block badge" id="reset" 
					          style="background-color: #d9534f;">
					          stok habis</span>';
			}else{
				$disabled = '';
				$info_stok = '<span class="help-block badge" id="reset" 
					          style="background-color: #5cb85c;">stok : '
					          .$barang->stok_barang.'</span>';
			}

			echo '<div class="form-group">
				      <label class="control-label col-md-3" 
				      	for="nama_barang">Nama Barang :</label>
				      <div class="col-md-8">
				        <input type="text" class="form-control reset" 
				        	name="nama_barang" id="nama_barang" 
				        	value="'.$barang->nama_barang.'"
				        	readonly="readonly">
				      </div>
				    </div>
				    <div class="form-group">
				      <label class="control-label col-md-3" 
				      	for="harga_barang">Harga (Rp) :</label>
				      <div class="col-md-8">
				        <input type="text" class="form-control reset" id="harga_barang" name="harga_barang" 
				        	value="'.number_format( $barang->harga_barang, 0 ,
				        	 '' , '.' ).'" readonly="readonly">
				      </div>
				    </div>
				    <div class="form-group">
				      <label class="control-label col-md-3" 
				      	for="qty">Quantity :</label>
				      <div class="col-md-4">
				        <input type="number" class="form-control reset" 
				        	name="qty" placeholder="Isi qty..." autocomplete="off" 
				        	id="qty" onchange="subTotal(this.value)" 
				        	onkeyup="subTotal(this.value)" min="0"  
				        	max="'.$barang->stok_barang.'" '.$disabled.'>
				      </div>'.$info_stok.'
				    </div>';
	    }else{

	    	echo '<div class="form-group">
				      <label class="control-label col-md-3" 
				      	for="nama_barang">Nama Barang :</label>
				      <div class="col-md-8">
				        <input type="text" class="form-control reset" 
				        	name="nama_barang" id="nama_barang" 
				        	readonly="readonly">
				      </div>
				    </div>
				    <div class="form-group">
				      <label class="control-label col-md-3" 
				      	for="harga_barang">Harga (Rp) :</label>
				      <div class="col-md-8">
				        <input type="text" class="form-control reset" 
				        	name="harga_barang" id="harga_barang" 
				        	readonly="readonly">
				      </div>
				    </div>
				    <div class="form-group">
				      <label class="control-label col-md-3" 
				      	for="qty">Quantity :</label>
				      <div class="col-md-4">
				        <input type="number" class="form-control reset" 
				        	autocomplete="off" onchange="subTotal(this.value)" 
				        	onkeyup="subTotal(this.value)" id="qty" min="0"  
				        	name="qty" placeholder="Isi qty..." autocomplete="off" id="qty" onchange="subTotal(this.value)" min="0"
				        	max="'.$barang['stok_barang'].'" '.$disabled.'>
				      </div>'.$info_stok.'
				    </div>';
	    }

	}

	public function ajax_list_transaksi()
	{
		$data = array();

		$no = 1; 
        
        foreach ($this->cart->contents() as $items){
        	
			$row = array();
			$row[] = $no;
			$row[] = $items["id"];
			$row[] = $items["name"];
			$row[] = 'Rp. ' . number_format( $items['price'], 
                    0 , '' , '.' ) . ',-';
			$row[] = $items["qty"];
			$row[] = 'Rp. ' . number_format( $items['subtotal'], 
					0 , '' , '.' ) . ',-';

			//add html for action
			$row[] = '<a 
				href="javascript:void()" style="color:rgb(255,128,128);
				text-decoration:none" onclick="deletebarang('
					."'".$items["rowid"]."'".','."'".$items['subtotal'].
					"'".')"> <i class="fa fa-close"></i> Delete</a>';
		
			$data[] = $row;
			$no++;
        }

		$output = array(
						"data" => $data,
				);
		//output to json format
		echo json_encode($output);
	}

	public function selesai()
	{
		$data1['no_nota'] = 'TRNSJ' .date('ymdhi');
		$data1['tgl_transaksi'] = date('Y-m-d');
		$no_nota = $data1['no_nota'];

		$data2 = array();
			foreach ($this->cart->contents() as $items) {
				$data2[]= array(
					'no_nota'=>'$no_nota',
					'subtotal'=>$items['subtotal']
				);
			}
			$this->kasir_model->save_as($data1,$data2);
			$data["transaksi"] = $this->transaksi_model->getDataTransaksi();
	        $this->load->view('report/report_transaksi', $data);
	}

	public function addbarang()
	{

		$data = array(
				'id' => $this->input->post('id_barang'),
				'name' => $this->input->post('nama_barang'),
				'price' => str_replace('.', '', $this->input->post(
					'harga_barang')),
				'qty' => $this->input->post('qty')
			);
		$insert = $this->cart->insert($data);
		echo json_encode(array("status" => TRUE));
	}

	public function deletebarang($rowid) 
	{

		$this->cart->update(array(
				'rowid'=>$rowid,
				'qty'=>0,));
		echo json_encode(array("status" => TRUE));
	}

	public function data_transaksi()
   	{	
   		$data["transaksi"] = $this->transaksi_model->getDataTransaksi();
   		if( $this->input->post('keyword') ) {
            $data["transaksi"] = $this->transaksi_model->cariDataTransaksi();
        }
        $this->load->view("transaksi",$data);
        $this->load->view("footer");
    }
    public function getDataTransaksifill($date)
    {
    	echo "<tr class='bg-dark text-light'><br>
                <th class='col-md-2'>TANGGAL</th>
                <th class='col-md-2'>NO NOTA</th>
                <th class='col-md-2'>ID BARANG</th>
                <th class='col-md-2'>NAMA BARANG</th>
                <th class='col-md-2'>HARGA BARANG</th>
                <th class='col-md-2'>QUANTITY</th>
                <th class='col-md-2'>SUBTOTAL</th>
                
                <th class='col-md-2'>AKSI</th>
            </tr>";

        $transaksi = $this->transaksi_model->getDataTransaksifill($date);
	    foreach($transaksi as $transaksi){
	    	echo "
	    		<tr>
		            <td class='align-middle'>". $transaksi['tgl_transaksi']."</td>
		            <td class='align-middle'>". $transaksi['no_nota']."</td>
		            <td class='align-middle'>". $transaksi['id_barang']."</td>
		            <td class='align-middle'>". $transaksi['nama_barang']."</td>
		            <td class='align-middle'>". $transaksi['harga_barang']."</td>
		            <td class='align-middle'>". $transaksi['quantity']."</td>
		            <td class='align-middle'>". $transaksi['subTotal']."</td>
		            <td class=' text-center'>
		                <a href='#". $transaksi['no_nota']."' onclick='hapusT('". $transaksi['no_nota']."')' class='btn btn-danger'>Hapus</a>
		            </td>
		        </tr>
	    	";
	    }
    }

    public function hapusDataTransaksi($no_nota)
    {
        $this->kasir_model->hapusDataTransaksi($no_nota);
        redirect("kasir/data_transaksi");
    }

    public function data_barang()
    {	

    	$data["barang"] = $this->kasir_model->getDataBarang();
    	if( $this->input->post('keyword') ) {
            $data['barang'] = $this->kasir_model->cariDataBarang();
        }
		$this->load->view("dataBarang",$data);
		$this->load->view("footer");
    }

    public function dataKasir()
    {	

    	$data["barang"] = $this->kasir_model->getDataBarang();
    	if( $this->input->post('keyword') ) {
            $data['barang'] = $this->kasir_model->cariDataBarangK();
        }
		$this->load->view("kasir/dataBarangK",$data);
		$this->load->view("footer");
    }

     public function tambah_barang()
        {	
            $this->form_validation->set_rules('id_barang','ID_BARANG', 'required|numeric');
            $this->form_validation->set_rules('nama_barang','NAMA BARANG', 'required');
            $this->form_validation->set_rules('harga_barang','HARGA', 'required');
            $this->form_validation->set_rules('stok_barang','STOK', 'required');
            if ($this->form_validation->run() == FALSE) {
                $data["barang"] = $this->kasir_model->getDataBarang();
                $this->load->view("tambahBarang", $data);
            }  
            else{
                $this->kasir_model->tambahDataBarang();
                redirect("kasir/data_barang");
            }
        }

    	public function ubah_barang($id_barang)
        {
            $data["barang"] = $this->kasir_model->getBarangByid($id_barang); 
            $this->form_validation->set_rules('nama_barang','NAMA BARANG', 'required');
            $this->form_validation->set_rules('harga_barang','HARGA', 'required');
            if ($this->form_validation->run() == FALSE) {
                $data["data_barang"] = $this->kasir_model->getDataBarang();
                $this->load->view("editBarang", $data);
            }  
            else{
                $this->kasir_model->ubahDataBarang($id_barang);
                redirect("kasir/data_barang");
            }
        }

        public function hapusDataBarang($id)
        {
            $this->kasir_model->hapusDataBarang($id);
            redirect("kasir/data_barang");
        }


    public function list_akun()
    {	

    	$data["akun"] = $this->akun_model->getDataAkun();
		$this->load->view("listAkun",$data);
		$this->load->view("footer");
    }
    public function tambah_akun()
    {
    	$this->form_validation->set_rules('kode_pegawai','KODE PEGAWAI', 'required|numeric');
        $this->form_validation->set_rules('username','USERNAME', 'required');
        $this->form_validation->set_rules('password','PASSWORD', 'required');
        $this->form_validation->set_rules('nama_pegawai','NAMA PEGAWAI', 'required');
        $this->form_validation->set_rules('hak_akses','HAK AKSES', 'required');
        if ($this->form_validation->run() == FALSE) {
            $data["akun"] = $this->akun_model->getDataAkun();
            $this->load->view("tambahAkun", $data);
        }  
        else{
            $this->akun_model->tambahDataAkun();
            redirect("kasir/list_akun");
        }
    }

    public function hapusDataAkun($id)
    {
    	$this->akun_model->hapusDataAkun($id);
    	redirect("kasir/list_akun");
    }


    public function report_barang()
    {
        $data["barang"] = $this->kasir_model->getDataBarang();
        $this->load->view('report/report_barang', $data);
    }

 
	
}