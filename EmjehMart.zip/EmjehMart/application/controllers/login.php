<?php 

	class login extends CI_Controller{
		function __construct(){
			parent::__construct();
			$this->load->model('login_model');
		}

		function index(){
			$this->load->view('login');
		}

		function auth(){
			$username = $this->input->post('username',TRUE);
			$password = password_verify(['password']);
			$validate = $this->login_model->validate($username,$password);
			if ($validate->num_rows()>0) {
				$data = $validate->row_array();
				$username = $data['username'];
				$hak_akses = $data['hak_akses'];
				$sesdata = array(
					'username' 	=>	$username,
					'hak_akses' =>	$hak_akses,
					'logged_in' => TRUE
				);
				$this->session->set_userdata($sesdata);
				if ($hak_akses == 'admin') {
					redirect('page/pegawai');
				} else if ($hak_akses == 'kasir'){
					redirect('page/pegawai');
				}
			}else{
				echo $this->session->set_flashdata('messege','
					<div class="alert alert-danger">
						<h4>Opss</h4>
						<p>Username atau Password Salah !</p>
					</div>');
				redirect('login');
			}
		}

		function logout(){
			$this->session->sess_destroy();
			redirect('login');
		}
	}

 ?>