-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 14 Mei 2019 pada 06.48
-- Versi Server: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `kasir`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `barang`
--

CREATE TABLE IF NOT EXISTS `barang` (
  `id_barang` varchar(20) NOT NULL,
  `nama_barang` varchar(50) NOT NULL,
  `stok_barang` int(10) NOT NULL,
  `harga_barang` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `barang`
--

INSERT INTO `barang` (`id_barang`, `nama_barang`, `stok_barang`, `harga_barang`) VALUES
('10254785', 'Beng-Beng', 5, 2000),
('10256347', 'Chitato', 3, 5000),
('10875643', 'Kripik Kusuka', 1, 6500),
('10896547', 'Mizon', 10, 7000),
('8995229001568', 'Buku', 7, 5000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `det_transaksi`
--

CREATE TABLE IF NOT EXISTS `det_transaksi` (
  `tgl_transaksi` date NOT NULL,
  `no_nota` int(10) NOT NULL,
  `id_barang` varchar(20) NOT NULL,
  `nama_barang` varchar(50) NOT NULL,
  `harga_barang` varchar(30) NOT NULL,
  `quantity` varchar(10) NOT NULL,
  `subTotal` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Trigger `det_transaksi`
--
DELIMITER //
CREATE TRIGGER `Pengurangan` AFTER INSERT ON `det_transaksi`
 FOR EACH ROW BEGIN
	UPDATE barang SET stok_barang=stok_barang-NEW.quantity
    WHERE id_barang = NEW.id_barang;
END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `head_transaksi`
--

CREATE TABLE IF NOT EXISTS `head_transaksi` (
`no_nota` int(10) NOT NULL,
  `tgl_transaksi` date NOT NULL,
  `subTotal` varchar(30) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=153 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `head_transaksi`
--

INSERT INTO `head_transaksi` (`no_nota`, `tgl_transaksi`, `subTotal`) VALUES
(29, '2019-04-30', ''),
(30, '2019-04-30', ''),
(31, '2019-04-30', ''),
(32, '2019-04-30', ''),
(33, '2019-04-30', ''),
(34, '2019-04-30', ''),
(35, '2019-04-30', ''),
(36, '2019-04-30', ''),
(37, '2019-04-30', ''),
(38, '2019-04-30', ''),
(39, '2019-04-30', ''),
(40, '2019-04-30', ''),
(41, '2019-04-30', ''),
(42, '2019-04-30', ''),
(43, '2019-04-30', ''),
(44, '2019-04-30', ''),
(45, '2019-04-30', ''),
(46, '2019-04-30', ''),
(47, '2019-04-30', ''),
(48, '2019-04-30', ''),
(49, '2019-04-30', ''),
(50, '2019-04-30', ''),
(51, '2019-04-30', ''),
(52, '2019-04-30', ''),
(53, '2019-04-30', ''),
(54, '2019-04-30', ''),
(55, '2019-04-30', ''),
(56, '2019-05-02', ''),
(57, '2019-05-02', ''),
(58, '2019-05-02', ''),
(59, '2019-05-02', ''),
(60, '2019-05-02', ''),
(61, '2019-05-02', ''),
(62, '2019-05-02', ''),
(63, '2019-05-02', ''),
(64, '2019-05-02', ''),
(65, '2019-05-02', ''),
(66, '2019-05-02', ''),
(67, '2019-05-02', ''),
(68, '2019-05-02', ''),
(69, '2019-05-02', ''),
(70, '2019-05-02', ''),
(71, '2019-05-02', ''),
(72, '2019-05-02', ''),
(73, '2019-05-02', ''),
(74, '2019-05-02', ''),
(75, '2019-05-10', ''),
(76, '2019-05-10', ''),
(77, '2019-05-10', ''),
(78, '2019-05-10', ''),
(79, '2019-05-10', ''),
(80, '2019-05-10', ''),
(81, '2019-05-10', ''),
(82, '2019-05-10', ''),
(83, '2019-05-10', ''),
(84, '2019-05-10', ''),
(85, '2019-05-10', ''),
(86, '2019-05-10', ''),
(87, '2019-05-10', ''),
(88, '2019-05-10', ''),
(89, '2019-05-10', ''),
(90, '2019-05-10', ''),
(91, '2019-05-10', ''),
(92, '2019-05-10', ''),
(93, '2019-05-10', ''),
(94, '2019-05-10', ''),
(95, '2019-05-10', ''),
(96, '2019-05-10', ''),
(97, '2019-05-10', ''),
(98, '2019-05-10', ''),
(99, '2019-05-10', ''),
(100, '2019-05-10', ''),
(101, '2019-05-10', ''),
(102, '2019-05-10', ''),
(103, '2019-05-10', ''),
(104, '2019-05-10', ''),
(105, '2019-05-10', ''),
(106, '2019-05-10', ''),
(107, '2019-05-10', ''),
(108, '2019-05-10', ''),
(109, '2019-05-10', ''),
(110, '2019-05-10', ''),
(111, '2019-05-10', ''),
(112, '2019-05-10', ''),
(113, '2019-05-10', ''),
(114, '2019-05-10', ''),
(115, '2019-05-10', ''),
(116, '2019-05-10', ''),
(117, '2019-05-10', ''),
(118, '2019-05-10', ''),
(119, '2019-05-10', ''),
(120, '2019-05-10', ''),
(121, '2019-05-10', ''),
(122, '2019-05-10', ''),
(123, '2019-05-10', ''),
(124, '2019-05-10', ''),
(125, '2019-05-10', ''),
(126, '2019-05-10', ''),
(127, '2019-05-10', ''),
(128, '2019-05-10', ''),
(129, '2019-05-10', ''),
(130, '2019-05-10', ''),
(131, '2019-05-10', ''),
(132, '2019-05-10', ''),
(133, '2019-05-13', ''),
(134, '2019-05-13', ''),
(135, '2019-05-13', ''),
(136, '2019-05-13', ''),
(137, '2019-05-13', ''),
(138, '2019-05-13', ''),
(139, '2019-05-13', ''),
(140, '2019-05-13', ''),
(141, '2019-05-13', ''),
(142, '2019-05-13', ''),
(143, '2019-05-13', ''),
(144, '2019-05-13', ''),
(145, '2019-05-13', ''),
(146, '2019-05-13', ''),
(147, '2019-05-13', ''),
(148, '2019-05-13', ''),
(149, '2019-05-13', ''),
(150, '2019-05-14', ''),
(151, '2019-05-14', ''),
(152, '2019-05-14', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pegawai`
--

CREATE TABLE IF NOT EXISTS `pegawai` (
  `kode_pegawai` int(10) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `nama_pegawai` varchar(50) NOT NULL,
  `hak_akses` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pegawai`
--

INSERT INTO `pegawai` (`kode_pegawai`, `username`, `password`, `nama_pegawai`, `hak_akses`) VALUES
(101, 'admin', 'admin', 'Najiib Muhammad', 'admin'),
(102, 'kasir', 'kasir', 'Kakang Herdianto', 'kasir');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
 ADD PRIMARY KEY (`id_barang`);

--
-- Indexes for table `det_transaksi`
--
ALTER TABLE `det_transaksi`
 ADD KEY `id_barang` (`id_barang`), ADD KEY `no_nota` (`no_nota`);

--
-- Indexes for table `head_transaksi`
--
ALTER TABLE `head_transaksi`
 ADD PRIMARY KEY (`no_nota`);

--
-- Indexes for table `pegawai`
--
ALTER TABLE `pegawai`
 ADD PRIMARY KEY (`kode_pegawai`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `head_transaksi`
--
ALTER TABLE `head_transaksi`
MODIFY `no_nota` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=153;
--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `det_transaksi`
--
ALTER TABLE `det_transaksi`
ADD CONSTRAINT `det_transaksi_ibfk_3` FOREIGN KEY (`no_nota`) REFERENCES `head_transaksi` (`no_nota`),
ADD CONSTRAINT `det_transaksi_ibfk_4` FOREIGN KEY (`id_barang`) REFERENCES `barang` (`id_barang`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
